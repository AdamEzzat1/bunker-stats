pub(crate) mod mad;
pub(crate) mod trimmed_mean;

